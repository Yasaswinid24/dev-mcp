"""Developer MCP server: local git, tests, Docker, GitLab CI and project scaffolding.

Runs over stdio. All paths are restricted to the folders in DEV_MCP_ROOTS.

Environment variables:
  DEV_MCP_ROOTS     Folders to watch, separated by ";". Each one may contain projects
                    or be a git project itself (default: your home folder).
                    DEV_MCP_ROOT (single folder) still works.
  DEV_MCP_MY_REMOTES  Remotes for push_my_accounts, e.g. "yassu,origin". The last one
                    becomes the tracking (upstream) branch.
  DEV_MCP_LOG       Log file path (default: dev-helper.log next to server.py)
  GITLAB_URL        e.g. https://gitlab.com (default) or your university GitLab
  GITLAB_TOKEN      GitLab personal access token with read_api scope
"""

import functools
import inspect
import json
import os
import subprocess
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

try:  # mcp 2.x
    from mcp.server.mcpserver import MCPServer as _Server
except ImportError:  # mcp 1.x
    from mcp.server.fastmcp import FastMCP as _Server

mcp = _Server("dev-helper")

HERE = Path(__file__).resolve().parent
MAX_OUTPUT = 8000  # characters returned to the model


def _load_roots() -> list[Path]:
    raw = (
        os.environ.get("DEV_MCP_ROOTS")
        or os.environ.get("DEV_MCP_ROOT")
        or str(Path.home())
    )
    roots: list[Path] = []
    for part in raw.split(";"):
        if part.strip():
            r = Path(part.strip()).expanduser().resolve()
            if r not in roots:
                roots.append(r)
    return roots


ROOTS = _load_roots()
ROOT = ROOTS[0]  # where new projects are created
LOG_PATH = Path(os.environ.get("DEV_MCP_LOG") or HERE / "dev-helper.log")
LOG_MAX_BYTES = 1_000_000


def _log(tool: str, arguments: dict, result: str, seconds: float) -> None:
    """Append one JSON line per tool call. Never lets a logging problem break a tool."""
    try:
        if LOG_PATH.exists() and LOG_PATH.stat().st_size > LOG_MAX_BYTES:
            LOG_PATH.replace(LOG_PATH.with_name(LOG_PATH.name + ".1"))
        record = {
            "time": time.strftime("%Y-%m-%d %H:%M:%S"),
            "tool": tool,
            "args": arguments,
            "ok": not result.startswith(("Error", "exit code", "Refusing", "Unknown")),
            "result": result[:300],
            "seconds": round(seconds, 2),
        }
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
    except Exception:
        pass


def _safe(fn):
    """Turn expected errors into readable messages and log every call."""
    sig = inspect.signature(fn)

    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        started = time.time()
        try:
            arguments = dict(sig.bind_partial(*args, **kwargs).arguments)
        except TypeError:
            arguments = dict(kwargs)
        try:
            result = fn(*args, **kwargs)
        except ValueError as e:
            result = f"Error: {e}"
        except Exception as e:  # log unexpected failures, then let them propagate
            _log(fn.__name__, arguments, f"Error: unexpected {type(e).__name__}: {e}",
                 time.time() - started)
            raise
        if fn.__name__ != "show_log":
            _log(fn.__name__, arguments, str(result), time.time() - started)
        return result

    return wrapper


# ---------------------------------------------------------------- helpers
def _inside_roots(p: Path) -> bool:
    return any(p == r or r in p.parents for r in ROOTS)


def _project(path: str) -> Path:
    """Resolve a project folder by name or path; it must stay inside the allowed roots."""
    given = Path(path).expanduser()
    if given.is_absolute():
        candidates = [given.resolve()]
    else:
        candidates = []
        for r in ROOTS:
            options = []
            if r.name == path and r.is_dir():
                options.append(r)  # the root is itself the project
            child = (r / given).resolve()
            if child.is_dir():
                options.append(child)
            for o in options:
                if o not in candidates:
                    candidates.append(o)
        if len(candidates) > 1:
            raise ValueError(
                f"'{path}' is ambiguous, it matches: {[str(c) for c in candidates]}. "
                "Use the full path."
            )
        if not candidates:
            candidates = [(ROOTS[0] / given).resolve()]
    p = candidates[0]
    if not _inside_roots(p):
        raise ValueError(f"{p} is outside the allowed folders {[str(r) for r in ROOTS]}")
    if not p.is_dir():
        raise ValueError(f"{p} is not a folder")
    return p


def _run(args: list[str], cwd: Path, timeout: int = 120) -> str:
    """Run a command without a shell and return trimmed combined output."""
    try:
        r = subprocess.run(
            args, cwd=cwd, capture_output=True, text=True, timeout=timeout
        )
    except FileNotFoundError:
        return f"Command not found: {args[0]}. Is it installed and on PATH?"
    except subprocess.TimeoutExpired:
        return f"Timed out after {timeout}s: {' '.join(args)}"
    out = (r.stdout + r.stderr).strip()
    if len(out) > MAX_OUTPUT:
        out = "...(truncated)...\n" + out[-MAX_OUTPUT:]
    return f"exit code {r.returncode}\n{out}" if r.returncode else (out or "ok")


SECRET_NAMES = {".env", "id_rsa", "id_ed25519", "credentials.json", "secrets.json"}
SECRET_SUFFIXES = (".pem", ".key", ".p12", ".pfx")


def _looks_secret(rel_path: str) -> bool:
    """True for files that usually hold credentials and should never be committed."""
    name = Path(rel_path).name.lower()
    if name in SECRET_NAMES or name.startswith(".env."):
        return name != ".env.example"
    return name.endswith(SECRET_SUFFIXES)


def _inside(project: Path, rel: str) -> str:
    """Return rel as a path relative to the project, refusing anything that escapes it."""
    full = (project / rel).resolve()
    if full != project and project not in full.parents:
        raise ValueError(f"{rel} is outside the project folder")
    return str(full.relative_to(project)) if full != project else "."


def _changed_files(project: Path) -> list[str]:
    """Paths of modified, new or deleted files according to git status."""
    out = subprocess.run(
        ["git", "status", "--porcelain", "-uall"],
        cwd=project, capture_output=True, text=True,
    ).stdout
    return [line[3:].strip().strip('"') for line in out.splitlines() if line]


def _staged_files(project: Path) -> list[str]:
    """Paths currently staged for the next commit."""
    out = subprocess.run(
        ["git", "diff", "--cached", "--name-only"],
        cwd=project, capture_output=True, text=True,
    ).stdout
    return [line for line in out.splitlines() if line]


def _python_for(project: Path) -> str:
    """Prefer the project's own virtual environment, else python on PATH."""
    for rel in (".venv/Scripts/python.exe", ".venv/bin/python",
                "venv/Scripts/python.exe", "venv/bin/python"):
        candidate = project / rel
        if candidate.exists():
            return str(candidate)
    return "python"


def _push(p: Path, remotes: list[str], branch: str, confirm: bool) -> str:
    """Shared push logic: validate remotes, dry run unless confirmed, then push each."""
    known = _run(["git", "remote"], p).split()
    unknown = [r for r in remotes if r not in known]
    if unknown:
        return f"Unknown remotes {unknown}. Configured remotes: {known}"
    if not confirm:
        return (
            f"DRY RUN: would push '{branch}' to {remotes}. "
            "Call again with confirm=true after the user agrees."
        )
    results = []
    for r in remotes:
        results.append(f"--- {r} ---\n" + _run(["git", "push", "-u", r, branch], p, 180))
    return "\n".join(results)


# ------------------------------------------------------------------- git
@mcp.tool()
@_safe
def list_projects() -> list[str]:
    """List git projects found in the watched folders (the folders themselves included)."""
    found: set[str] = set()
    for r in ROOTS:
        if not r.is_dir():
            continue
        if (r / ".git").exists():
            found.add(r.name)
        try:
            for d in r.iterdir():
                if d.is_dir() and (d / ".git").exists():
                    found.add(d.name)
        except OSError:
            continue
    return sorted(found)


@mcp.tool()
@_safe
def git_status(project: str) -> str:
    """Show branch, changed files and configured remotes for a project folder."""
    p = _project(project)
    return (
        _run(["git", "status", "--short", "--branch"], p)
        + "\n\nRemotes:\n"
        + _run(["git", "remote", "-v"], p)
    )


@mcp.tool()
@_safe
def git_commit(
    project: str,
    message: str,
    files: list[str] | None = None,
    add_all: bool = False,
) -> str:
    """Create a commit. By default only commits what is already staged.

    Pass files=["a.py", "README.md"] to stage and commit just those files, or
    add_all=true to stage everything. Staging everything is refused if it would
    include likely secrets (.env, keys, tokens). Use git_diff first to review.
    """
    p = _project(project)
    if not message.strip():
        return "Commit message must not be empty."

    if files:
        safe_files = [_inside(p, f) for f in files]
        bad = [f for f in safe_files if _looks_secret(f)]
        if bad:
            return f"Refusing to stage likely secret files: {bad}"
        added = _run(["git", "add", "--", *safe_files], p)
        if added.startswith("exit code"):
            return added
    elif add_all:
        bad = [f for f in _changed_files(p) if _looks_secret(f)]
        if bad:
            return (
                f"Refusing add_all: these look like secrets: {bad}. "
                "Add them to .gitignore, or commit chosen files with files=[...]."
            )
        added = _run(["git", "add", "-A"], p)
        if added.startswith("exit code"):
            return added

    if not _staged_files(p):
        changed = _changed_files(p)
        return (
            "Nothing is staged, so nothing was committed. "
            f"Changed files: {changed or 'none'}. "
            "Call again with files=[...] or add_all=true."
        )
    return _run(["git", "commit", "-m", message], p)


@mcp.tool()
@_safe
def git_diff(project: str, staged: bool = False, path: str = "") -> str:
    """Show what changed: a file summary plus the diff (truncated if very long).

    staged=true shows what is staged for the next commit. path limits it to one file.
    Use this to review changes before committing and to write a good commit message.
    """
    p = _project(project)
    base = ["git", "diff"] + (["--cached"] if staged else [])
    tail = ["--", _inside(p, path)] if path else []
    stat = _run(base + ["--stat"] + tail, p)
    body = _run(base + tail, p)
    return f"{stat}\n\n{body}" if body != "ok" else "No changes."


@mcp.tool()
@_safe
def git_push(
    project: str, remotes: list[str], branch: str = "main", confirm: bool = False
) -> str:
    """Push a branch to one or more named remotes (for example ["sai", "yassu"]).

    Pushing changes other people's repositories, so it only runs when confirm=True.
    Ask the user to confirm the remote names first.
    """
    return _push(_project(project), remotes, branch, confirm)


@mcp.tool()
@_safe
def push_my_accounts(project: str, branch: str = "main", confirm: bool = False) -> str:
    """Push a branch to your own accounts' remotes, set in DEV_MCP_MY_REMOTES.

    One call replaces pushing to each account separately. Dry run unless confirm=true,
    so show the user the remotes and ask first. The last remote in the list becomes the
    branch's upstream (tracking) remote.
    """
    remotes = [r.strip() for r in os.environ.get("DEV_MCP_MY_REMOTES", "").split(",") if r.strip()]
    if not remotes:
        raise ValueError('Set DEV_MCP_MY_REMOTES in the MCP config, for example "yassu,origin".')
    return _push(_project(project), remotes, branch, confirm)


@mcp.tool()
@_safe
def show_log(count: int = 20) -> str:
    """Show the most recent tool calls this server ran (time, tool, arguments, outcome)."""
    count = max(1, min(count, 100))
    if not LOG_PATH.exists():
        return "No calls logged yet."
    lines = LOG_PATH.read_text(encoding="utf-8").splitlines()[-count:]
    out = []
    for line in lines:
        try:
            rec = json.loads(line)
        except ValueError:
            continue
        status = "ok" if rec.get("ok") else "FAILED"
        out.append(
            f"{rec['time']}  {rec['tool']}  {json.dumps(rec['args'], ensure_ascii=False)}"
            f"  -> {status} ({rec['seconds']}s)"
        )
    return "\n".join(out) or "No calls logged yet."


@mcp.tool()
@_safe
def git_log(project: str, count: int = 10) -> str:
    """Show the last few commits, one per line."""
    p = _project(project)
    count = max(1, min(count, 50))
    return _run(["git", "log", f"-{count}", "--oneline", "--decorate"], p)


# ------------------------------------------------------- tests and docker
@mcp.tool()
@_safe
def run_tests(project: str, extra_args: str = "") -> str:
    """Run pytest in a project folder and return the summary and failures."""
    p = _project(project)
    py = _python_for(p)
    args = [py, "-m", "pytest", "-q", "--tb=short"]
    if extra_args.strip():
        args += extra_args.split()
    return f"Using Python: {py}\n" + _run(args, p, timeout=300)


@mcp.tool()
@_safe
def docker_build(project: str, tag: str) -> str:
    """Build a Docker image from the Dockerfile in a project folder."""
    p = _project(project)
    if not (p / "Dockerfile").exists():
        return "No Dockerfile found in this project."
    if not tag or any(c.isspace() for c in tag):
        return "Provide a tag without spaces, like myapp:dev."
    return _run(["docker", "build", "-t", tag, "."], p, timeout=600)


# ---------------------------------------------------------------- GitLab
def _gitlab(path: str):
    base = os.environ.get("GITLAB_URL", "https://gitlab.com").rstrip("/")
    token = os.environ.get("GITLAB_TOKEN")
    if not token:
        raise ValueError("Set GITLAB_TOKEN (read_api scope) in the MCP config.")
    req = urllib.request.Request(
        f"{base}/api/v4{path}", headers={"PRIVATE-TOKEN": token}
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        raise ValueError(f"GitLab returned {e.code} for {path}") from e


@mcp.tool()
@_safe
def gitlab_pipeline_status(project_path: str) -> str:
    """Show the latest pipeline and any failed jobs for a GitLab project.

    project_path is the full path, such as "group/subgroup/project".
    """
    pid = urllib.parse.quote(project_path, safe="")
    pipelines = json.loads(_gitlab(f"/projects/{pid}/pipelines?per_page=1"))
    if not pipelines:
        return "No pipelines found."
    pl = pipelines[0]
    lines = [
        f"Pipeline #{pl['id']} on '{pl['ref']}': {pl['status']}",
        f"Link: {pl['web_url']}",
    ]
    jobs = json.loads(_gitlab(f"/projects/{pid}/pipelines/{pl['id']}/jobs?per_page=50"))
    failed = [j for j in jobs if j["status"] == "failed"]
    for j in failed:
        lines.append(f"FAILED job '{j['name']}' (stage {j['stage']}) - {j['web_url']}")
    if not failed:
        lines.append("No failed jobs.")
    return "\n".join(lines)


@mcp.tool()
@_safe
def gitlab_failed_job_log(project_path: str, job_id: int, last_lines: int = 60) -> str:
    """Return the last lines of a job log, to see why a CI job failed."""
    pid = urllib.parse.quote(project_path, safe="")
    log = _gitlab(f"/projects/{pid}/jobs/{job_id}/trace")
    tail = "\n".join(log.splitlines()[-max(1, min(last_lines, 300)):])
    return tail[-MAX_OUTPUT:]


# -------------------------------------------------------------- scaffold
@mcp.tool()
@_safe
def scaffold_fastapi_project(name: str) -> str:
    """Create a new FastAPI project (app, test, Dockerfile, CI file, README) in the root."""
    if not name.replace("-", "").replace("_", "").isalnum():
        return "Use letters, numbers, - or _ only for the project name."
    p = ROOT / name
    if p.exists():
        return f"{p} already exists. Choose another name."
    (p / "app").mkdir(parents=True)
    (p / "tests").mkdir()
    files = {
        "app/__init__.py": "",
        "app/main.py": (
            "from fastapi import FastAPI\n\napp = FastAPI(title=\"" + name + "\")\n\n\n"
            "@app.get(\"/health\")\ndef health():\n    return {\"status\": \"ok\"}\n"
        ),
        "tests/test_health.py": (
            "from fastapi.testclient import TestClient\n\nfrom app.main import app\n\n\n"
            "def test_health():\n    r = TestClient(app).get(\"/health\")\n"
            "    assert r.status_code == 200\n    assert r.json() == {\"status\": \"ok\"}\n"
        ),
        "requirements.txt": "fastapi\nuvicorn\nhttpx\npytest\n",
        "Dockerfile": (
            "FROM python:3.12-slim\nWORKDIR /code\n"
            "COPY requirements.txt .\nRUN pip install --no-cache-dir -r requirements.txt\n"
            "COPY app app\n"
            "CMD [\"uvicorn\", \"app.main:app\", \"--host\", \"0.0.0.0\", \"--port\", \"8000\"]\n"
        ),
        ".gitlab-ci.yml": (
            "test:\n  image: python:3.12-slim\n  script:\n"
            "    - pip install -r requirements.txt\n    - pytest -q\n"
        ),
        ".gitignore": "__pycache__/\n.venv/\n.env\n",
        "README.md": f"# {name}\n\nRun: `uvicorn app.main:app --reload`\n\nTest: `pytest`\n",
    }
    for rel, content in files.items():
        (p / rel).write_text(content, encoding="utf-8")
    _run(["git", "init", "-b", "main"], p)
    return f"Created {p} with {len(files)} files and initialised git."


if __name__ == "__main__":
    mcp.run()
